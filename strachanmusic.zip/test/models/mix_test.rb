require 'test_helper'

class MixTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
